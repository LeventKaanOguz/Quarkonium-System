# Results added in v1.2.0 (not part of the v1.1.0 sweeps)

Everything here was produced with the commands below, seed 20261011, basis 37,0.05,15 (fits) and the PDG subset
fixture `tests/data/pdg-subset.sqlite`, which gives the same numbers as the full PDG 2026 file for the states used.

- `gi-sandwich/`: `qgem_study gi-levels` (closure) and `qgem_study gi-levels --sandwich exact`, GI levels at the BGS
  (m = 1.628) and GM (m = 4.977) parameters, eight levels per channel up to L = 3.
- `bc-interp/`: the B_c prediction with the interpolation systematic (`sigma_interp_GeV` in the JSON) for the four
  representatives (A const/first, B APT/first, C const (s free), D GI (s free)), first pass; `--multistart 2` (B: `--multistart 8`
  with the v1.1.0 minima as `--start`).
- `contact/`: `qgem_study contact-r0`, |R(0)|² with the contact term outside and inside H for σ = 0.8, 1.13, 2, 3 GeV.

---

# Results added in v1.2.0

Produced by `python3 analysis/sweep.py rep oneloop cx screen studies` (seeded with the v1.1.0 `main` minima;
`QGEM_PDG=tests/data/pdg-subset.sqlite`), then `python3 analysis/summarize_v12.py`. Each run has the JSON, the printed
table (`.txt`) and the log with the command line (`.log`).

- `rep/`: the four representatives again; they reproduce `main` to 5e-8 relative in the parameters and 1.3e-5 MeV in
  the masses, and add the B_c interpolation systematic.
- `oneloop/`: Models A and B, constant coupling, first-order spin: tree level and the one-loop short-distance
  potential at mu_ref = 1, 2, 3 GeV (`-ol1`, `-ol2`, `-ol3`).
- `cx/`: fits with a mixed basis of 25 real and 6 complex ranges (`--basis 25,0.05,15 --complex 6,0.8,15,0.5`).
- `screen/`: the screening mass fitted (`-fit`), shared by c c-bar and b b-bar (`-shared`), and fixed at 0.02 ... 0.5 GeV.
- `studies/`: `qgem_study` outputs (GI levels with closure and exact sandwiches, contact term, complex-range levels).
- `v1.2-summary.md`: the tables of all of the above.
- `medium/`: `python3 examples/medium_dissociation.py results/main/A-const-coff-first.json --out results/medium`, the screening
  masses mu* of the S and P states (first order in the stored wave function and exact), a figure and the log.
