# Results added in v1.2.0 (not part of the v1.1.0 sweeps)

Everything here was produced with the commands below, seed 20261011, basis 37,0.05,15 (fits) and the PDG subset
fixture `tests/data/pdg-subset.sqlite`, which gives the same numbers as the full PDG 2026 file for the states used.

- `gi-sandwich/`: `qgem_study gi-levels` (closure) and `qgem_study gi-levels --sandwich exact`, GI levels at the BGS
  (m = 1.628) and GM (m = 4.977) parameters, eight levels per channel up to L = 3.
- `bc-interp/`: the B_c prediction with the interpolation systematic (`sigma_interp_GeV` in the JSON) for the four
  representatives (A const/first, B APT/first, C const (s free), D GI (s free)); `--multistart 2` (B: `--multistart 8`
  with the v1.1.0 minima as `--start`).
- `oneloop/`: Models A and B, `--running const --spin first`, tree level (`*_tree`) and `--one-loop --mu-ref`
  1, 2, 3 GeV; `--multistart 20 --loo`.
- `contact/`: `qgem_study contact-r0`, |R(0)|² with the contact term outside and inside H for σ = 0.8, 1.13, 2, 3 GeV.
